// ToolBoost — dukungan Lua: validator sintaks (parser Lua 5.4 lengkap) + runner (Fengari, Lua 5.3 di browser).
(function () {
  var KW = {};
  'and break do else elseif end false for function goto if in local nil not or repeat return then true until while'.split(' ').forEach(function (k) { KW[k] = 1; });
  var OPS = ['...', '..', '==', '~=', '<=', '>=', '<<', '>>', '//', '::', '+', '-', '*', '/', '%', '^', '#', '&', '~', '|', '<', '>', '=', '(', ')', '{', '}', '[', ']', ';', ':', ',', '.'];
  var HINT_OPS = { '!=': "Lua memakai '~=' untuk 'tidak sama dengan', bukan '!='", '&&': "Lua memakai 'and', bukan '&&'", '||': "Lua memakai 'or', bukan '||'", '!': "Lua memakai 'not', bukan '!'" };

  function LuaErr(line, col, msg) { this.line = line; this.col = col; this.message = msg; }

  function lex(src) {
    var toks = [], i = 0, n = src.length, line = 1, ls = 0;
    function err(l, c, m) { throw new LuaErr(l, c, m); }
    function longBracket(at) {
      var m = /^\[(=*)\[/.exec(src.slice(at, at + 64));
      return m ? m[1].length : -1;
    }
    function readLong(at, lvl, what) {
      var sl = line, sc = at - ls + 1, close = ']' + '='.repeat(lvl) + ']';
      var e = src.indexOf(close, at + lvl + 2);
      if (e < 0) err(sl, sc, what + ' panjang belum ditutup (butuh ' + close + ')');
      for (var k = at; k < e; k++) if (src[k] === '\n') { line++; ls = k + 1; }
      return e + close.length;
    }
    while (i < n) {
      var c = src[i];
      if (c === '\n') { line++; ls = ++i; continue; }
      if (c === ' ' || c === '\t' || c === '\r' || c === '\f' || c === '\v') { i++; continue; }
      var col = i - ls + 1;
      if (c === '-' && src[i + 1] === '-') {
        var lv = src[i + 2] === '[' ? longBracket(i + 2) : -1;
        if (lv >= 0) { i = readLong(i + 2, lv, 'Komentar'); continue; }
        while (i < n && src[i] !== '\n') i++;
        continue;
      }
      if (i === 0 && c === '#' && src[1] === '!') { while (i < n && src[i] !== '\n') i++; continue; }
      if (c === '[') {
        var lv2 = longBracket(i);
        if (lv2 >= 0) { var sl0 = line; i = readLong(i, lv2, 'String'); toks.push({ t: 'str', v: 'string', line: sl0, col: col }); continue; }
      }
      if (c === '"' || c === "'") {
        var j = i + 1;
        for (;;) {
          if (j >= n || src[j] === '\n') err(line, col, 'String belum ditutup (kutip ' + c + ' menggantung)');
          var d = src[j];
          if (d === c) break;
          if (d === '\\') {
            var e2 = src[j + 1];
            if (e2 === '\n') { line++; ls = j + 2; j += 2; continue; }
            if (e2 === 'z') { j += 2; while (j < n && /\s/.test(src[j])) { if (src[j] === '\n') { line++; ls = j + 1; } j++; } continue; }
            if (e2 === 'x') { if (!/^[0-9a-fA-F]{2}$/.test(src.substr(j + 2, 2))) err(line, j - ls + 1, "Escape '\\x' butuh tepat 2 digit heksadesimal"); j += 4; continue; }
            if (e2 === 'u') { if (!/^\{[0-9a-fA-F]+\}/.test(src.slice(j + 2, j + 12))) err(line, j - ls + 1, "Escape '\\u' harus berbentuk \\u{XXX}"); j = src.indexOf('}', j) + 1; continue; }
            if (/[0-9]/.test(e2)) { var m3 = /^[0-9]{1,3}/.exec(src.slice(j + 1, j + 4)); if (+m3[0] > 255) err(line, j - ls + 1, 'Escape desimal terlalu besar (maks \\255)'); j += 1 + m3[0].length; continue; }
            if ('abfnrtv\\"\'\r'.indexOf(e2) < 0) err(line, j - ls + 1, "Escape '\\" + (e2 || '') + "' tidak valid di string Lua");
            j += 2; continue;
          }
          j++;
        }
        toks.push({ t: 'str', v: 'string', line: line, col: col }); i = j + 1; continue;
      }
      if (/[0-9]/.test(c) || (c === '.' && /[0-9]/.test(src[i + 1] || ''))) {
        var m = /^0[xX](?:[0-9a-fA-F]*\.?[0-9a-fA-F]*)(?:[pP][+-]?[0-9]+)?|^(?:[0-9]+\.?[0-9]*|\.[0-9]+)(?:[eE][+-]?[0-9]+)?/.exec(src.slice(i, i + 200));
        var len = m[0].length;
        if (/[A-Za-z0-9_.]/.test(src[i + len] || '') || /^0[xX]$/.test(m[0])) {
          var bad = /^[A-Za-z0-9_.]+/.exec(src.slice(i))[0];
          err(line, col, "Angka tidak valid: '" + bad + "'");
        }
        toks.push({ t: 'num', v: m[0], line: line, col: col }); i += len; continue;
      }
      if (/[A-Za-z_]/.test(c)) {
        var w = /^[A-Za-z_][A-Za-z0-9_]*/.exec(src.slice(i, i + 256))[0];
        toks.push({ t: KW[w] ? 'kw' : 'name', v: w, line: line, col: col }); i += w.length; continue;
      }
      var two = src.substr(i, 2);
      if (HINT_OPS[two]) err(line, col, HINT_OPS[two]);
      var op = null;
      for (var q = 0; q < OPS.length; q++) if (src.startsWith(OPS[q], i)) { op = OPS[q]; break; }
      if (!op) {
        if (HINT_OPS[c]) err(line, col, HINT_OPS[c]);
        err(line, col, "Karakter tidak dikenal '" + c + "'");
      }
      toks.push({ t: 'op', v: op, line: line, col: col }); i += op.length;
    }
    toks.push({ t: 'eof', v: '<akhir file>', line: line, col: i - ls + 1 });
    return toks;
  }

  var BIN = { 'or': [1, 1], 'and': [2, 2], '<': [3, 3], '>': [3, 3], '<=': [3, 3], '>=': [3, 3], '~=': [3, 3], '==': [3, 3],
    '|': [4, 4], '~': [5, 5], '&': [6, 6], '<<': [7, 7], '>>': [7, 7], '..': [9, 8], '+': [10, 10], '-': [10, 10],
    '*': [11, 11], '/': [11, 11], '//': [11, 11], '%': [11, 11], '^': [14, 13] };
  var UNARY_PRI = 12;

  function parse(src) {
    var toks = lex(src), p = 0, tk = toks[0];
    var fs = { vararg: true, loops: 0 };
    function next() { p++; tk = toks[p]; }
    function near(t) { t = t || tk; return t.t === 'eof' ? '<akhir file>' : "'" + (t.t === 'str' ? 'string' : t.v) + "'"; }
    function err(msg, t) { t = t || tk; throw new LuaErr(t.line, t.col, msg); }
    function is(v) { return (tk.t === 'op' || tk.t === 'kw') && tk.v === v; }
    function accept(v) { if (is(v)) { next(); return true; } return false; }
    function expect(v, hint) { if (!accept(v)) err("'" + v + "' diharapkan di dekat " + near() + (hint ? ' — ' + hint : '')); }
    function match(what, who, line) {
      if (accept(what)) return;
      if (line === tk.line) err("'" + what + "' diharapkan di dekat " + near());
      err("'" + what + "' diharapkan (untuk menutup '" + who + "' di baris " + line + ') di dekat ' + near());
    }
    function name() {
      if (tk.t !== 'name') err('Nama (identifier) diharapkan di dekat ' + near() + (tk.t === 'kw' ? " — '" + tk.v + "' adalah kata kunci Lua" : ''));
      next();
    }
    function blockFollow(withUntil) {
      if (tk.t === 'eof') return true;
      if (tk.t !== 'kw') return false;
      return tk.v === 'else' || tk.v === 'elseif' || tk.v === 'end' || (withUntil && tk.v === 'until');
    }
    function block() {
      while (!blockFollow(true)) {
        if (is('return')) { retstat(); return; }
        statement();
      }
    }
    function retstat() {
      next();
      if (!blockFollow(true) && !is(';')) explist();
      accept(';');
      if (!blockFollow(true)) err("Kode setelah 'return' tidak diizinkan — 'return' harus jadi pernyataan terakhir di blok (bungkus dengan 'do return end' jika perlu)");
    }
    function statement() {
      var t = tk, line = tk.line;
      if (tk.t === 'op') {
        if (tk.v === ';') { next(); return; }
        if (tk.v === '::') { next(); name(); expect('::'); return; }
      }
      if (tk.t === 'kw') switch (tk.v) {
        case 'if': ifstat(line); return;
        case 'while': next(); expr(); expect('do'); fs.loops++; block(); fs.loops--; match('end', 'while', line); return;
        case 'do': next(); block(); match('end', 'do', line); return;
        case 'for': forstat(line); return;
        case 'repeat': next(); fs.loops++; block(); fs.loops--; match('until', 'repeat', line); expr(); return;
        case 'function': next(); funcname(); body(line, true); return;
        case 'local':
          next();
          if (accept('function')) { name(); body(line, false); return; }
          do {
            name();
            if (accept('<')) {
              var at = tk; name();
              if (at.v !== 'const' && at.v !== 'close') err("Atribut tidak dikenal '" + at.v + "' (hanya <const> atau <close>)", at);
              expect('>');
            }
          } while (accept(','));
          if (accept('=')) explist();
          return;
        case 'return': retstat(); return;
        case 'break':
          if (!fs.loops) err("'break' di luar perulangan (loop)", t);
          next(); return;
        case 'goto': next(); name(); return;
      }
      exprstat();
    }
    function ifstat(line) {
      next(); expr(); expect('then', "di Lua, 'if' ditulis: if kondisi then ... end"); block();
      while (is('elseif')) { next(); expr(); expect('then'); block(); }
      if (accept('else')) block();
      match('end', 'if', line);
    }
    function forstat(line) {
      next(); name();
      if (accept('=')) {
        expr(); expect(',', "for numerik ditulis: for i = awal, akhir[, langkah] do"); expr();
        if (accept(',')) expr();
      } else if (is(',') || is('in')) {
        while (accept(',')) name();
        expect('in'); explist();
      } else err("'=' atau 'in' diharapkan di dekat " + near());
      expect('do'); fs.loops++; block(); fs.loops--; match('end', 'for', line);
    }
    function funcname() { name(); while (accept('.')) name(); if (accept(':')) name(); }
    function body(line, _) {
      var saved = fs; fs = { vararg: false, loops: 0 };
      expect('(');
      if (!is(')')) {
        do {
          if (accept('...')) { fs.vararg = true; break; }
          name();
        } while (accept(','));
      }
      expect(')', 'parameter fungsi harus berupa nama atau ...');
      block();
      match('end', 'function', line);
      fs = saved;
    }
    function explist() { var n = 1; expr(); while (accept(',')) { expr(); n++; } return n; }
    function primaryexp() {
      if (tk.t === 'name') { next(); return 'var'; }
      if (is('(')) { var line = tk.line; next(); expr(); match(')', '(', line); return 'paren'; }
      if (tk.t === 'op' && (tk.v === '//' )) err("Simbol tak terduga '//' — komentar di Lua memakai '--'");
      if (tk.t === 'op' && tk.v === '=' ) err("Simbol tak terduga '=' — mungkin maksudnya '==' untuk perbandingan?");
      err('Simbol tak terduga di dekat ' + near());
    }
    function suffixedexp() {
      var kind = primaryexp();
      for (;;) {
        if (is('.')) { next(); name(); kind = 'var'; }
        else if (is('[')) { next(); expr(); expect(']'); kind = 'var'; }
        else if (is(':')) { next(); name(); args(); kind = 'call'; }
        else if (is('(') || is('{') || tk.t === 'str') { args(); kind = 'call'; }
        else return kind;
      }
    }
    function args() {
      if (tk.t === 'str') { next(); return; }
      if (is('{')) { table(); return; }
      var line = tk.line; next();
      if (!is(')')) explist();
      match(')', '(', line);
    }
    function table() {
      var line = tk.line; next();
      while (!is('}')) {
        if (is('[')) { next(); expr(); expect(']'); expect('='); expr(); }
        else if (tk.t === 'name' && toks[p + 1].t === 'op' && toks[p + 1].v === '=') { next(); next(); expr(); }
        else expr();
        if (!accept(',') && !accept(';')) break;
      }
      match('}', '{', line);
    }
    function simpleexp() {
      if (tk.t === 'num' || tk.t === 'str') { next(); return; }
      if (tk.t === 'kw') {
        if (tk.v === 'nil' || tk.v === 'true' || tk.v === 'false') { next(); return; }
        if (tk.v === 'function') { var line = tk.line; next(); body(line, false); return; }
      }
      if (is('...')) { if (!fs.vararg) err("'...' tidak bisa dipakai di luar fungsi vararg (tambahkan ... di parameter fungsi)"); next(); return; }
      if (is('{')) { table(); return; }
      suffixedexp();
    }
    function expr(limit) {
      limit = limit || 0;
      if (is('not') || is('-') || is('#') || is('~')) { next(); expr(UNARY_PRI); }
      else simpleexp();
      for (;;) {
        var op = (tk.t === 'op' || tk.t === 'kw') ? BIN[tk.v] : null;
        if (!op || op[0] <= limit) return;
        next();
        expr(op[1]);
      }
    }
    function exprstat() {
      var start = tk, kind = suffixedexp();
      if (is('=') || is(',')) {
        if (kind !== 'var') err('Tidak bisa memberi nilai ke ekspresi ini (sisi kiri harus variabel)', start);
        while (accept(',')) { if (suffixedexp() !== 'var') err('Sisi kiri penugasan harus variabel', start); }
        expect('=');
        explist();
        return;
      }
      if (kind !== 'call') {
        if (tk.t === 'op' && /^[-+*/%^]$/.test(tk.v) && toks[p + 1] && toks[p + 1].v === '=')
          err("Lua tidak punya operator '" + tk.v + "='. Tulis: x = x " + tk.v + ' nilai');
        if (tk.t === 'op' && (tk.v === '+' || tk.v === '-') && toks[p + 1] && toks[p + 1].v === tk.v)
          err("Lua tidak punya operator '" + tk.v + tk.v + "'. Tulis: x = x " + tk.v + ' 1');
        err('Sintaks error di dekat ' + near() + ' — pernyataan harus berupa pemanggilan fungsi atau penugasan');
      }
    }
    block();
    if (tk.t !== 'eof') {
      if (is('end')) err("'end' berlebih — tidak ada blok yang perlu ditutup");
      if (is('until')) err("'until' tanpa 'repeat'");
      if (is('else') || is('elseif')) err("'" + tk.v + "' tanpa 'if'");
      err('Akhir file diharapkan di dekat ' + near());
    }
  }

  function validate(code) {
    try { parse(String(code || '')); return []; }
    catch (e) {
      if (e instanceof LuaErr) return [{ line: e.line, col: e.col, message: e.message }];
      return [];
    }
  }

  // ── Runner: Fengari (Lua 5.3 VM murni JavaScript) ──
  var FENGARI_URL = 'https://cdn.jsdelivr.net/npm/fengari-web@0.1.4/dist/fengari-web.js';
  var loading = null;
  function load() {
    if (window.fengari) return Promise.resolve(window.fengari);
    if (loading) return loading;
    loading = new Promise(function (res, rej) {
      // Monaco memasang loader AMD; sembunyikan sementara agar bundle UMD Fengari memasang window.fengari.
      var amd = window.define; window.define = undefined;
      var s = document.createElement('script');
      s.src = FENGARI_URL; s.async = true;
      s.onload = function () { window.define = amd; window.fengari ? res(window.fengari) : (loading = null, rej(new Error('Fengari gagal dimuat'))); };
      s.onerror = function () { window.define = amd; loading = null; rej(new Error('Runtime Lua gagal dimuat — periksa koneksi internet.')); };
      document.head.appendChild(s);
    });
    return loading;
  }
  function run(code, onOut, opts) {
    opts = opts || {};
    return load().then(function (F) {
      var lua = F.lua, lauxlib = F.lauxlib, lualib = F.lualib, S = F.to_luastring, J = F.to_jsstring;
      var L = lauxlib.luaL_newstate();
      lualib.luaL_openlibs(L);
      var buf = '';
      function flush(force) {
        var k;
        while ((k = buf.indexOf('\n')) >= 0) { onOut(buf.slice(0, k), ''); buf = buf.slice(k + 1); }
        if (force && buf) { onOut(buf, ''); buf = ''; }
      }
      lua.lua_pushjsfunction(L, function (L) {
        var nArgs = lua.lua_gettop(L), parts = [];
        for (var i = 1; i <= nArgs; i++) { parts.push(J(lauxlib.luaL_tolstring(L, i))); lua.lua_pop(L, 1); }
        buf += parts.join('\t') + '\n'; flush();
        return 0;
      });
      lua.lua_setglobal(L, S('print'));
      lua.lua_pushjsfunction(L, function (L) {
        var nArgs = lua.lua_gettop(L);
        for (var i = 1; i <= nArgs; i++) { buf += J(lauxlib.luaL_tolstring(L, i)); lua.lua_pop(L, 1); }
        flush();
        return 0;
      });
      lua.lua_setglobal(L, S('__tb_write'));
      var input = String(opts.stdin || '').split('\n'), ip = 0;
      lua.lua_pushjsfunction(L, function (L) {
        if (ip >= input.length || (ip === input.length - 1 && input[ip] === '')) { lua.lua_pushnil(L); return 1; }
        lua.lua_pushstring(L, S(input[ip++])); return 1;
      });
      lua.lua_setglobal(L, S('__tb_read'));
      var setupSt = lauxlib.luaL_dostring(L, S(
        'io = io or {}\n' +
        'io.write = function(...) for i = 1, select("#", ...) do __tb_write(tostring((select(i, ...)))) end return io end\n' +
        'io.read = function() return __tb_read() end\n' +
        'io.stdout = io.stdout or { write = function(self, ...) return io.write(...) end }\n' +
        'os.exit = function() error("os.exit dipanggil", 0) end'));
      if (setupSt !== lua.LUA_OK) {
        var se = J(lua.lua_tostring(L, -1) || S('setup error'));
        return { ok: false, error: 'Gagal menyiapkan runtime Lua: ' + se, elapsed: 0 };
      }
      var t0 = Date.now(), limit = opts.timeoutMs || 10000;
      lua.lua_sethook(L, function (L) {
        if (Date.now() - t0 > limit) lauxlib.luaL_error(L, S('Dihentikan: eksekusi lebih dari ' + Math.round(limit / 1000) + ' detik (kemungkinan perulangan tak berujung)'));
      }, lua.LUA_MASKCOUNT, 20000);
      var st = lauxlib.luaL_loadbuffer(L, S(code), null, S('=' + (opts.name || 'main.lua')));
      var ok = st === lua.LUA_OK;
      if (ok) {
        lua.lua_getglobal(L, S('debug')); lua.lua_getfield(L, -1, S('traceback')); lua.lua_remove(L, -2);
        lua.lua_insert(L, 1);
        st = lua.lua_pcall(L, 0, 0, 1);
        ok = st === lua.LUA_OK;
      }
      flush(true);
      var error = ok ? null : J(lua.lua_tostring(L, -1) || S('Error'));
      return { ok: ok, error: error, elapsed: Date.now() - t0 };
    });
  }

  window.TBLua = { validate: validate, run: run, load: load };
})();
