/* ToolBoostPro Mobile — service worker */
var V = 'tb-shell-v34-lua', RT = 'tb-runtime-v1';
var SHELL = ['./', 'index.html', 'tb-i18n.js', 'monaco-loader.js', 'tb-lua.js', 'manifest.webmanifest',
  'favicon/favicon.svg', 'favicon/favicon-192.png', 'favicon/favicon-512.png', 'favicon/maskable-192.png', 'favicon/maskable-512.png'];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(V).then(function (c) {
    return Promise.all(SHELL.map(function (u) { return c.add(new Request(u, { cache: 'reload' })).catch(function () {}); }));
  }).then(function () { return self.skipWaiting(); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (ks) {
    return Promise.all(ks.filter(function (k) { return k !== V && k !== RT; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});

function put(name, req, res) {
  if (res && (res.ok || res.type === 'opaque')) { var cl = res.clone(); caches.open(name).then(function (c) { return c.put(req, cl); }).catch(function () {}); }
  return res;
}
function firstMatch(keys, opts) {
  return keys.reduce(function (p, k) { return p.then(function (hit) { return hit || caches.match(k, opts); }); }, Promise.resolve(undefined));
}
function offlinePage() {
  return new Response('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Offline</title><body style="background:#14100D;color:#F5F1EA;font-family:system-ui;display:grid;place-items:center;min-height:100vh;margin:0;text-align:center;padding:24px"><div><h2>Offline</h2><p style="color:#A69C8D">Open ToolBoost once while online so it can work offline.</p><button onclick="location.reload()" style="margin-top:12px;padding:12px 20px;border:0;border-radius:10px;background:#C05A31;color:#fff;font-weight:600">Try again</button></div>', { headers: { 'Content-Type': 'text/html; charset=utf-8' } });
}

self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  var u = new URL(req.url);
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return;
  if (u.origin === self.location.origin) {
    var nav = req.mode === 'navigate';
    e.respondWith(fetch(req).then(function (r) { return put(V, req, r); }).catch(function () {
      return caches.match(req, { ignoreSearch: nav }).then(function (hit) {
        if (hit) return hit;
        if (!nav) return Response.error();
        return firstMatch(['index.html', './'], { ignoreSearch: true }).then(function (h) { return h || offlinePage(); });
      });
    }));
    return;
  }
  if (u.hostname === 'cdn.jsdelivr.net' && /\/(monaco-editor@|pyodide\/v|fengari-web@)/.test(u.pathname)) {
    e.respondWith(caches.match(req).then(function (hit) { return hit || fetch(req).then(function (r) { return put(RT, req, r); }); }));
    return;
  }
  if (u.hostname === 'fonts.googleapis.com' || u.hostname === 'fonts.gstatic.com') {
    e.respondWith(caches.match(req).then(function (hit) {
      var net = fetch(req).then(function (r) { return put(RT, req, r); });
      return hit || net;
    }));
  }
});
