/* ToolBoost — bahasa / language.
 *
 * Satu tabel kanonik PAIRS = [[english, indonesia], …]. Kedua arah kamus
 * (EN→ID dan ID→EN) diturunkan dari tabel itu, jadi tidak ada lagi dua daftar
 * yang bisa berbeda isi. Karena tabelnya simetris, teks sumber yang campur
 * Indonesia/Inggris tetap berakhir satu bahasa utuh, dan mengganti bahasa
 * bisa dilakukan tanpa reload.
 *
 * Bahasa default = bahasa browser. Pilihan eksplisit user (tombol Auto/EN/ID)
 * disimpan di localStorage dan selalu menang.
 */
(function () {
  'use strict';

  var LANG_KEY = 'toolboost_lang';

  /* ═══════════════════════════════════════════════════════════════════
     TABEL KANONIK — [English, Indonesia]
     ═══════════════════════════════════════════════════════════════════ */
  var PAIRS = [
    /* ── Intro & landing ─────────────────────────────────────────── */
    ['Click to skip →', 'Klik untuk lewati →'],
    ['Replay intro', 'Putar ulang intro'],
    ['FREE ONLINE CODE EDITOR · POWERED BY AI', 'EDITOR KODE ONLINE GRATIS · DIDUKUNG AI'],
    ['greet a list of names', 'sapa daftar nama'],
    ['✓ Accept', '✓ Terima'],
    ['AI Chat', 'Chat AI'],
    ['free model', 'model gratis'],
    ['What does this code print?', 'Kode ini mencetak apa?'],
    ['One greeting per name — three lines, starting with', 'Satu sapaan per nama — tiga baris, diawali'],
    ['Python · in your browser', 'Python · di browser kamu'],
    ['✓ Finished in 0.04s — no server, no install', '✓ Selesai dalam 0,04 dtk — tanpa server, tanpa install'],
    ['AI ready', 'AI siap'],
    ['Ghost-text autocomplete — accept with Tab', 'Autocomplete ghost text — terima dengan Tab'],
    ['Inline edit — describe the change, AI rewrites it', 'Edit inline — jelaskan perubahannya, AI yang menulis ulang'],
    ['AI chat that sees your code', 'Chat AI yang paham kode kamu'],
    ['Run JavaScript, Python, HTML & CSS in the browser', 'Jalankan JavaScript, Python, HTML & CSS di browser'],
    ['Free online code editor,', 'Editor kode online gratis,'],
    ['No install', 'Tanpa install'],
    ['No sign-up', 'Tanpa daftar'],
    ['Works on your phone', 'Bisa di HP'],
    ['What do you want to build?', 'Mau bikin apa hari ini?'],
    ['Help', 'Bantuan'],
    ['How ToolBoost works', 'Cara pakai ToolBoost'],
    ['Chat with the AI, it writes the code, you run it. No install, no sign-up.', 'Ngobrol dengan AI, AI menulis kodenya, kamu tinggal jalankan. Tanpa install, tanpa daftar.'],
    ['Shortcuts', 'Pintasan'],
    ['Close', 'Tutup'],
    ['Describe an app, a page or a script. The code appears on the right, ready to run.', 'Ceritakan aplikasi, halaman, atau skrip yang kamu mau. Kodenya muncul di kanan, siap dijalankan.'],
    ['Landing page for a coffee shop', 'Landing page untuk kedai kopi'],
    ['Snake game in JavaScript', 'Game Snake pakai JavaScript'],
    ['Python script that parses a CSV', 'Skrip Python untuk membaca CSV'],
    ['Describe what you want to build…', 'Ceritakan apa yang mau kamu bikin…'],
    ['Simple (chat first)', 'Simpel (fokus chat)'],
    ['Classic IDE', 'IDE klasik'],
    ['Show code', 'Tampilkan kode'],
    ['Change model', 'Ganti model'],
    ['Preview / output', 'Pratinjau / output'],
    ['Start building — it\u2019s free', 'Mulai bikin — gratis'],
    ['Start building — it\'s free', 'Mulai bikin — gratis'],
    ['THOUSANDS OF AI REQUESTS · NO INSTALL', 'RIBUAN REQUEST AI · TANPA INSTALL'],
    ['AI CODE EDITOR · RUNS IN YOUR BROWSER', 'EDITOR KODE AI · JALAN DI BROWSER'],
    ['NO INSTALL · NO ACCOUNT · NO LOGIN', 'TANPA INSTALL · TANPA AKUN · TANPA LOGIN'],
    ['✦ No install · No account', '✦ Tanpa install · Tanpa akun'],
    ['Generous AI request quota', 'Kuota request AI melimpah'],
    ["Free online code editor,","Editor kode online gratis,"],
    ["Free online code editor, powered by AI","Editor kode online gratis, ditenagai AI"],
    ["Run JavaScript, Python, HTML and CSS in your browser or on your phone — with AI autocomplete, Ctrl+K inline edits and chat. No install, no sign-up.","Jalankan JavaScript, Python, HTML dan CSS di browser atau HP — dengan autocomplete AI, edit inline Ctrl+K dan chat. Tanpa install, tanpa daftar."],
    ["Frequently asked questions","Pertanyaan yang sering diajukan"],
    ["Is ToolBoost really free?","Apakah ToolBoost benar-benar gratis?"],
    ["Yes. ToolBoost is a free online code editor with AI. You can write, run and refactor code without paying and without creating an account. AI features use free models through OpenRouter with a generous daily request quota.","Ya. ToolBoost adalah editor kode online gratis dengan AI. Kamu bisa menulis, menjalankan dan refactor kode tanpa bayar dan tanpa membuat akun. Fitur AI memakai model gratis lewat OpenRouter dengan kuota request harian yang melimpah."],
    ["Do I need to install anything?","Apakah perlu install sesuatu?"],
    ["No. ToolBoost runs entirely in your web browser — Chrome, Edge, Firefox or Safari, on desktop or phone. Open the page and start coding.","Tidak. ToolBoost berjalan sepenuhnya di browser — Chrome, Edge, Firefox atau Safari, di komputer maupun HP. Buka halamannya dan langsung coding."],
    ["Which programming languages can I run?","Bahasa pemrograman apa saja yang bisa dijalankan?"],
    ["You can run JavaScript, Python, HTML and CSS directly in the browser, with syntax highlighting for many more languages including TypeScript, C++, Java, Go and Rust.","JavaScript, Python, HTML dan CSS bisa dijalankan langsung di browser, plus syntax highlighting untuk banyak bahasa lain termasuk TypeScript, C++, Java, Go dan Rust."],
    ["How is ToolBoost different from GitHub Copilot or Cursor?","Apa bedanya ToolBoost dengan GitHub Copilot atau Cursor?"],
    ["ToolBoost gives you Copilot-style ghost-text autocomplete, Ctrl+K inline AI edits and an AI chat assistant, but in the browser and for free — no desktop app, no subscription.","ToolBoost memberi autocomplete ghost-text ala Copilot, edit AI inline Ctrl+K dan asisten chat AI, tapi di browser dan gratis — tanpa aplikasi desktop, tanpa langganan."],
    ["Can I code on my phone?","Apakah bisa coding di HP?"],
    ["Yes. The editor is mobile-friendly, so you can write and run code on Android or iPhone. Dalam Bahasa Indonesia: ToolBoost bisa dipakai untuk coding di HP secara gratis.","Bisa. Editornya ramah mobile, jadi kamu bisa menulis dan menjalankan kode di Android atau iPhone secara gratis."],
    ["Is my code saved or shared?","Apakah kode saya disimpan atau dibagikan?"],
    ["Your files stay in your browser. You can upload files, download them, or export your whole project as a .zip at any time.","File kamu tetap tersimpan di browser. Kamu bisa upload, download, atau export seluruh project sebagai .zip kapan saja."],
    ["Python editor online","Editor Python online"],
    ["JavaScript playground","Playground JavaScript"],
    ["HTML & CSS editor","Editor HTML & CSS"],
    ["About","Tentang"],
    ["Install App For Mobile","Install App For Mobile"],
    ["Templates","Template"],
    ["Start from a ready-made example. Files are added to your project — nothing is overwritten.","Mulai dari contoh siap pakai. File ditambahkan ke project — tidak ada yang tertimpa."],
    ["Install ToolBoost as an app on your phone: its own icon on the home screen, full-screen editor, and it opens even without internet.","Pasang ToolBoost sebagai aplikasi di HP: ikon sendiri di layar utama, editor layar penuh, dan tetap bisa dibuka tanpa internet."],
    ["Full-screen editor","Editor layar penuh"],
    ["Works offline","Bisa offline"],
    ["Coding keys bar","Baris tombol coding"],
    ["Close","Tutup"],
    ["Install","Pasang"],
    ["ToolBoostPro IDE — free online AI code editor · Built with ♥ · Powered by","ToolBoostPro IDE — editor kode AI online gratis · Dibuat dengan ♥ · Didukung"],
    ["Privacy","Privasi"],
    ["Terms","Ketentuan"],
    ['Launch Editor', 'Buka Editor'],
    ['A real code editor,', 'Editor kode sungguhan,'],
    ['powered by AI', 'ditenagai AI'],
    ['A real code editor, powered by AI', 'Editor kode sungguhan, ditenagai AI'],
    ['Write, run, and refactor code right in the browser — no install, no account. Ghost-text autocomplete, Ctrl+K inline edits, and side-by-side diffs, all built in.',
     'Tulis, jalankan, dan refactor kode langsung di browser — tanpa install, tanpa akun. Autocomplete ghost-text, edit inline Ctrl+K, dan diff berdampingan, semuanya sudah tersedia.'],
    ['or press', 'atau tekan'],
    ['to start', 'untuk mulai'],
    ['Donate BTC', 'Donasi BTC'],
    ['Donate', 'Donasi'],
    ['Support Developer', 'Dukung Developer'],
    ['AI Chat Assistant', 'Asisten Chat AI'],
    ['Ask anything about your code. Get instant answers, refactors, and fixes with full editor context.',
     'Tanya apa pun soal kodemu. Dapat jawaban, refactor, dan perbaikan instan dengan konteks editor penuh.'],
    ['Ghost Text Autocomplete', 'Autocomplete Ghost Text'],
    ['AI predicts your next line as you type. Press Tab to accept — like GitHub Copilot, in the browser.',
     'AI menebak baris berikutmu sambil kamu mengetik. Tekan Tab untuk terima — seperti GitHub Copilot, di browser.'],
    ['Inline Edit (Ctrl+K)', 'Edit Inline (Ctrl+K)'],
    ['Select code, press Ctrl+K, describe what you want. AI rewrites it in-place. Cursor-style magic.',
     'Pilih kode, tekan Ctrl+K, jelaskan maumu. AI menulis ulang di tempat. Ajaib seperti Cursor.'],
    ['Built with ♥ · Powered by', 'Dibuat dengan ♥ · Ditenagai'],
    ['free models', 'model gratis'],
    ['Weekly sales', 'Penjualan mingguan'],
    ['LIVE COMPONENT · 0 DEPENDENCIES', 'KOMPONEN LIVE · 0 DEPENDENSI'],
    ['preview · running in this tab', 'pratinjau · jalan di tab ini'],
    ['a sales bar chart that animates in', 'grafik batang penjualan yang beranimasi masuk'],

    /* ── Editor chrome ───────────────────────────────────────────── */
    ['Language', 'Bahasa'],
    ['Follow browser language', 'Ikuti bahasa browser'],
    ['English', 'English'],
    ['Indonesian', 'Indonesia'],
    ['Auto', 'Auto'],
    ['Inline AI', 'AI Inline'],
    ['Focus Chat', 'Fokus Chat'],
    ['Run Code', 'Jalankan Kode'],
    ['Commands', 'Perintah'],
    ['Explain', 'Jelaskan'],
    ['Debug', 'Debug'],
    ['Refactor', 'Refactor'],
    ['Add Comments', 'Tambah Komentar'],
    ['Write Tests', 'Tulis Tes'],
    ['Optimize', 'Optimalkan'],
    ['Deep Think', 'Pikir Mendalam'],
    ['Auto-Apply', 'Terap Otomatis'],
    ['Write Mode', 'Mode Tulis'],
    ['Agent', 'Agen'],
    ['EXPLORER', 'BERKAS'],
    ['Output', 'Keluaran'],
    ['Terminal', 'Terminal'],
    ['Clear', 'Bersihkan'],
    ['Run', 'Jalankan'],
    ['Validate', 'Periksa'],
    ['Accept', 'Terima'],
    ['Reject', 'Tolak'],
    ['Settings', 'Pengaturan'],
    ['⚙ Settings', '⚙ Pengaturan'],
    ['Font Size', 'Ukuran Font'],
    ['Tab Size', 'Ukuran Tab'],
    ['2 spaces', '2 spasi'],
    ['4 spaces', '4 spasi'],
    ['New File', 'File Baru'],
    ['New Project', 'Proyek Baru'],
    ['New chat', 'Chat baru'],
    ['Clear chat', 'Bersihkan chat'],
    ['Cancel', 'Batal'],
    ['Create', 'Buat'],
    ['Toggle Sidebar', 'Buka/Tutup Sidebar'],
    ['Toggle AI Chat', 'Buka/Tutup Chat AI'],
    ['Upload File from Device', 'Unggah File dari Perangkat'],
    ['Open File (Ctrl+O)', 'Buka File (Ctrl+O)'],
    ['New file (Ctrl+N)', 'File baru (Ctrl+N)'],
    ['Copy entire file', 'Salin seluruh file'],
    ['Multi-Agent Discussion', 'Diskusi Multi-Agen'],
    ['Run code (Ctrl+Enter)', 'Jalankan kode (Ctrl+Enter)'],
    ['Send (Enter)', 'Kirim (Enter)'],
    ['Send to AI (Enter)', 'Kirim ke AI (Enter)'],
    ['Close (Esc)', 'Tutup (Esc)'],
    ['Loading model…', 'Memuat model…'],
    ['Loading free models…', 'Memuat model gratis…'],
    ['loading…', 'memuat…'],
    ['Ask me anything about your code.', 'Tanya apa saja tentang kodemu.'],
    ['I have full context of your editor.', 'Aku punya konteks penuh editormu.'],
    ['filename (e.g. main.js)', 'nama file (mis. main.js)'],
    ['Type a command or search files... (e.g. >New File)', 'Ketik perintah atau cari file… (mis. >New File)'],
    ['Check JS/CSS syntax validity (including inline in HTML)', 'Cek validitas sintaks JS/CSS (termasuk yang inline di HTML)'],
    ['Ask the AI… (Enter to send, Shift+Enter for a new line)', 'Tanya AI… (Enter kirim, Shift+Enter baris baru)'],
    ['Type an instruction for the AI… (Enter = Send)', 'Ketik instruksi untuk AI... (Enter = Send)'],
    ['Type a command… (Enter to run)', 'Ketik perintah… (Enter untuk jalankan)'],
    ['AI models · ranked automatically', 'Model AI · diurutkan otomatis'],
    ['Free models via OpenRouter (auto-detected).', 'Model gratis via OpenRouter (auto-detected).'],
    ['Pick a model from the list above to switch the AI.', 'Pilih model dari daftar di atas untuk mengganti AI.'],
    ['Click the', 'Klik tombol'],
    ['button on any code block', 'di tiap code block'],
    ['to write straight into the editor!', 'untuk langsung tulis ke editor!'],
    ['ToolBoost ready. Click Apply on an AI code block to write straight into the editor.',
     'ToolBoost siap. Klik Apply pada code block AI untuk tulis langsung ke editor.'],

    /* ── Local terminal ──────────────────────────────────────────── */
    ['Paste the token from the companion app', 'Tempel token dari companion app'],
    ['Connect', 'Hubungkan'],
    ['Disconnect', 'Putuskan'],
    ['Disconnect connection', 'Putuskan koneksi'],
    ['in your terminal', 'di terminal Anda'],
    ['1. Run:', '1. Jalankan:'],
    ['2. Copy the token it prints into the field below', '2. Salin token yang muncul di sana ke kolom di bawah'],
    ['⚡ Enable Local Terminal…', '⚡ Aktifkan Local Terminal…'],
    ['Local Terminal runs commands directly on your computer through a small companion app you start yourself.',
     'Local Terminal menjalankan perintah langsung di komputer Anda lewat companion app kecil yang Anda jalankan sendiri.'],
    ['Enable Local Terminal?', 'Aktifkan Local Terminal?'],
    ['Yes, I Understand & Trust This', 'Ya, Saya Mengerti & Percaya'],
    ['Before continuing, make sure you understand:', 'Sebelum lanjut, pastikan Anda paham:'],
    ['on your own computer', 'di komputer Anda sendiri'],
    ['run any command', 'menjalankan perintah apa pun'],
    ['trust', 'mempercayai'],
    ['full', 'penuh'],
    ['The token was rejected by the companion app. Copy the token shown in your terminal again.',
     'Token ditolak companion app. Salin ulang token yang tampil di terminal.'],

    /* ── Akun ────────────────────────────────────────────────────── */
    ['Sign in', 'Masuk'],
    ['Sign up', 'Daftar'],
    ['Sign up free', 'Daftar gratis'],
    ['Sign out', 'Keluar'],
    ['Create account', 'Buat akun'],
    ['Creating…', 'Membuat…'],
    ['Username', 'Username'],
    ['Password', 'Password'],
    ['New password', 'Password baru'],
    ['Current password', 'Password sekarang'],
    ['Date of birth', 'Tanggal lahir'],
    ['Recovery code', 'Kode pemulihan'],
    ['Save your recovery code', 'Simpan kode pemulihanmu'],
    ['Copy code', 'Salin kode'],
    ['I have saved it', 'Sudah saya simpan'],
    ['Recover account', 'Pulihkan akun'],
    ['Recover & sign in', 'Pulihkan & masuk'],
    ['Forgot your password?', 'Lupa password?'],
    ['Back to sign in', 'Kembali ke halaman masuk'],
    ['Already have an account — Sign in', 'Sudah punya akun — Masuk'],
    ['Profile & security', 'Profil & keamanan'],
    ['Admin panel', 'Panel Admin'],
    ['Save changes', 'Simpan perubahan'],
    ['Display name', 'Nama tampilan'],
    ['Avatar colour', 'Warna avatar'],
    ['Sign up to continue', 'Daftar untuk lanjut'],
    ['Upgrade to Pro', 'Naik ke Pro'],
    ['Plan: Pro', 'Paket: Pro'],
    ['How to upgrade to Pro', 'Cara naik ke Pro'],
    ['Contact the admin on WhatsApp', 'Hubungi admin via WhatsApp'],
    ['Sign in to request Pro', 'Masuk untuk minta Pro'],
    ['Sign in first to request Pro', 'Masuk dulu untuk minta Pro'],
    ['Open the admin WhatsApp chat', 'Buka chat WhatsApp admin'],
    ['Unlock every editor limit.', 'Buka semua batasan editor.'],
    ['You are already Pro. Thank you!', 'Kamu sudah Pro. Terima kasih!'],
    ['A free account gives you', 'Dengan akun gratis kamu dapat'],
    ['The editor, running code, and Python all still work without an account.',
     'Editor, jalankan kode, dan Python tetap bisa dipakai tanpa akun.'],
    ['The editor works without an account. Accounts store your profile & preferences.',
     'Editor tetap bisa dipakai tanpa akun. Akun dipakai untuk menyimpan profil & preferensi.'],
    ['No email — just a username & password', 'Tanpa email — cukup username & password'],
    ['Save files & profile', 'Simpan file & profil'],
    ['Account registration is currently closed by the admin.', 'Pendaftaran akun sedang ditutup admin.'],
    ['Wrong username or password.', 'Username atau password salah.'],
    ['That username is taken.', 'Username sudah dipakai.'],
    ['This account is blocked. Contact the admin.', 'Akun ini diblokir. Hubungi admin.'],
    ['Wrong recovery code.', 'Kode pemulihan salah.'],
    ['Account not found, or it has no recovery code.', 'Akun tidak ditemukan atau tidak punya kode pemulihan.'],
    ['Your current password is wrong.', 'Password sekarang salah.'],
    ['Profile updated.', 'Profil diperbarui.'],
    ['Profile & password updated.', 'Profil & password diperbarui.'],
    ['You have signed out.', 'Kamu sudah keluar.'],
    ['Date of birth is required.', 'Tanggal lahir wajib diisi.'],
    ['The site is in maintenance mode. Only admins can sign in.',
     'Situs sedang dalam mode maintenance. Hanya admin yang bisa masuk.'],
    ['This device is connected to ToolBoost cloud.', 'Perangkat terhubung ke cloud ToolBoost.'],
    ['Storage is full — export, then clear old data.', 'Database penuh — export lalu hapus data lama.'],
    ['ToolBoost account', 'Akun ToolBoost'],
    ['Just a username & password — no email.', 'Username & password saja — tanpa email.'],
    ['Used to verify account age. Never shown publicly.',
     'Dipakai untuk verifikasi umur akun. Tidak pernah ditampilkan ke publik.'],
    ['You will be shown a recovery code once — keep it safe.',
     'Kamu akan diberi kode pemulihan sekali — simpan baik-baik.'],
    ['Username 3–20 characters — letters, numbers, and _ only', 'Username 3–20 karakter, hanya huruf, angka, dan _'],
    ['Username must be 3–20 characters (letters, numbers, and _ only).', 'Username 3–20 karakter (huruf, angka, dan _ saja).'],
    ['That username is taken. Try another.', 'Username itu sudah dipakai. Coba yang lain.'],
    ['Registration closed', 'Pendaftaran ditutup'],
    ['Enter the recovery code you saved when you signed up.', 'Masukkan kode pemulihan yang kamu simpan saat mendaftar.'],
    ['This is the only way to recover', 'Ini satu-satunya cara memulihkan'],
    ['if you forget your password. The code is shown only now — write it down or store it somewhere safe.',
     'kalau kamu lupa password. Kode hanya ditampilkan sekarang — tulis atau simpan di tempat aman.'],
    ['Recovery code copied.', 'Kode pemulihan disalin.'],
    ['The account could not be saved — browser storage may be full.',
     'Akun gagal tersimpan — penyimpanan browser mungkin penuh.'],
    ['Created straight from the admin panel — no email.', 'Dibuat langsung dari panel admin — tanpa email.'],
    ['New password for @', 'Password baru untuk @'],
    ['Something went wrong.', 'Terjadi kesalahan.'],
    ['Cancelled.', 'Dibatalkan.'],
    ['Saved.', 'Tersimpan.'],
    ['Saved:', 'Tersimpan:'],
    ['Sign in as an admin first.', 'Masuk dulu sebagai admin.'],
    ['Access denied — your account is not an admin.', 'Akses ditolak — akun kamu bukan admin.'],
    ['Show password', 'Tampilkan password'],
    ['Hide password', 'Sembunyikan password'],

    /* ── Panel admin ─────────────────────────────────────────────── */
    ['Overview', 'Ringkasan'],
    ['Users', 'Pengguna'],
    ['Pro requests', 'Permintaan Pro'],
    ['Database', 'Database'],
    ['Activity', 'Aktivitas'],
    ['Activity log', 'Log Aktivitas'],
    ['Sync', 'Sinkron'],
    ['Cloud sync', 'Sinkron Cloud'],
    ['New account', 'Akun baru'],
    ['Total accounts', 'Total akun'],
    ['Sign-ins today', 'Login hari ini'],
    ['Data size', 'Ukuran data'],
    ['Database rows', 'Baris database'],
    ['Account', 'Akun'],
    ['Role', 'Peran'],
    ['Plan', 'Paket'],
    ['Status', 'Status'],
    ['Created', 'Dibuat'],
    ['Last sign-in', 'Terakhir masuk'],
    ['Actions', 'Aksi'],
    ['Reset PW', 'Reset PW'],
    ['Block', 'Blokir'],
    ['Unblock', 'Buka blokir'],
    ['Delete', 'Hapus'],
    ['Approve Pro', 'Setujui Pro'],
    ['Reject request', 'Tolak'],
    ['Requested', 'Diminta'],
    ['Note', 'Catatan'],
    ['Duration', 'Masa aktif'],
    ['Pro duration', 'Masa aktif Pro'],
    ['Decision history', 'Riwayat keputusan'],
    ['Decided', 'Diputus'],
    ['By', 'Oleh'],
    ['Result', 'Hasil'],
    ['approved', 'disetujui'],
    ['rejected', 'ditolak'],
    ['No upgrade requests yet.', 'Belum ada permintaan upgrade.'],
    ['Awaiting approval', 'Menunggu persetujuan'],
    ['Connect another device', 'Hubungkan perangkat lain'],
    ['Connection link', 'Link koneksi'],
    ['Copy link', 'Salin link'],
    ['Copy SQL', 'Salin SQL'],
    ['Sync status', 'Status sinkron'],
    ['Sync now', 'Sinkronkan sekarang'],
    ['Syncing…', 'Menyinkronkan…'],
    ['Synced.', 'Tersinkron.'],
    ['Not configured', 'Belum diatur'],
    ['Enable cloud sync', 'Aktifkan sinkron cloud'],
    ['Automatic sync', 'Sinkron otomatis'],
    ['Provider', 'Penyedia'],
    ['Table name', 'Nama tabel'],
    ['Your own JSON endpoint', 'Endpoint JSON sendiri'],
    ['Export database', 'Export database'],
    ['Import database', 'Import database'],
    ['Reset database', 'Reset database'],
    ['Clear', 'Kosongkan'],
    ['Save', 'Simpan'],
    ['Site name', 'Nama situs'],
    ['Allow registration', 'Izinkan pendaftaran'],
    ['Maintenance mode', 'Mode maintenance'],
    ['Minimum password length', 'Panjang password minimum'],
    ['Default role for new accounts', 'Peran default akun baru'],
    ['Activity log limit', 'Batas jumlah log'],
    ['Free account AI quota', 'Kuota AI akun Free'],
    ['AI quota without an account', 'Kuota AI tanpa akun'],
    ['Free account file limit', 'Batas file akun Free'],
    ['Pro price label', 'Label harga Pro'],
    ['Pro duration (days)', 'Masa aktif Pro (hari)'],
    ['Pro-only AI models', 'Model AI khusus Pro'],
    ['Admin WhatsApp number', 'Nomor WhatsApp admin'],
    ['Settings saved.', 'Pengaturan disimpan.'],
    ['days', 'hari'],
    ['forever', 'selamanya'],
    ['no accounts yet', 'belum ada akun'],
    ['leave empty to keep it', 'kosongkan bila tak ganti'],
    ['Recent activity', 'Aktivitas terakhir'],
    ['No activity yet.', 'Belum ada aktivitas.'],
    ['Log is empty.', 'Log kosong.'],
    ['No matching accounts.', 'Tidak ada akun yang cocok.'],
    ['No rows match your search.', 'Tidak ada baris yang cocok dengan pencarian.'],
    ['Total sign-ins', 'Total masuk'],
    ['Last sign-in time', 'Login terakhir'],
    ['Joined', 'Bergabung'],
    ['Close panel', 'Tutup panel'],
    ['Table mode', 'Mode tabel'],
    ['Raw JSON', 'Raw JSON'],
    ['Edit row', 'Edit baris'],
    ['Save row', 'Simpan baris'],
    ['Save JSON', 'Simpan JSON'],
    ['Row saved.', 'Baris disimpan.'],
    ['Table contents', 'Isi tabel'],
    ['Table that stores the document', 'Tabel penyimpan dokumen'],
    ['Clear the entire table', 'Kosongkan seluruh tabel'],
    ['Clear table', 'Kosongkan tabel'],
    ['Delete log', 'Hapus log'],
    ['Reset everything', 'Reset semua'],
    ['Entire database', 'Seluruh database'],
    ['Backup & recovery', 'Backup & pemulihan'],
    ['Export JSON', 'Export JSON'],
    ['Delete all activity log entries?', 'Hapus semua log aktivitas?'],
    ['Delete all accounts, logs, and settings — back to a fresh state',
     'Hapus semua akun, log, dan pengaturan — kembali ke kondisi awal'],
    ['Type RESET to confirm:', 'Ketik RESET untuk konfirmasi:'],
    ['Reset the ENTIRE database? Every account will be lost.', 'Reset SELURUH database? Semua akun akan hilang.'],
    ['Overwrite the current database with this file? Existing data is lost.',
     'Timpa database sekarang dengan file ini? Data lama hilang.'],
    ['Unrecognised database format.', 'Format database tidak dikenali.'],
    ['JSON must be an array of rows.', 'JSON harus berupa array baris.'],
    ['Database exported.', 'Database diexport.'],
    ['Database imported.', 'Database diimport.'],
    ['Database reset to a fresh state.', 'Database direset ke kondisi awal.'],
    ['Applies to new accounts & resets', 'Berlaku untuk akun baru & reset'],
    ['When off, only admins can create accounts', 'Kalau mati, hanya admin bisa membuat akun'],
    ['Shown in the admin panel', 'Ditampilkan di panel admin'],
    ['Shown to users when they request a Pro upgrade', 'Ditampilkan ke user saat mereka minta upgrade Pro'],
    ['Oldest entries are dropped automatically', 'Entri paling lama dibuang otomatis'],
    ['AI requests per day; Pro is unlimited', 'Permintaan AI per hari; Pro tanpa batas'],
    ['Maximum number of files per workspace', 'Jumlah file maksimum per workspace'],
    ['Messages allowed before signing up is required · 0 = none',
     'Jumlah pesan yang boleh dikirim sebelum wajib daftar · 0 = tidak boleh'],
    ['Text shown on the upgrade page', 'Teks yang tampil di halaman upgrade'],
    ['How long Pro lasts once approved · 0 = forever', 'Lama Pro berlaku saat disetujui · 0 = selamanya'],
    ['Used when you approve a request · 0 = forever', 'Dipakai saat kamu menyetujui permintaan · 0 = selamanya'],
    ['How many top-ranked models are locked · 0 = all open',
     'Berapa model peringkat teratas yang dikunci · 0 = semua bebas'],
    ['Destination for Pro upgrade requests, format 628…', 'Tujuan permintaan upgrade Pro, format 628…'],
    ['WhatsApp number saved.', 'Nomor WhatsApp disimpan.'],
    ['Pro lasts forever per approval.', 'Pro aktif selamanya per persetujuan.'],
    ['Only admins may create owners.', 'Hanya admin yang boleh membuat owner.'],
    ['Only an owner can change an owner\u2019s role.', 'Hanya owner yang bisa mengubah peran owner.'],
    ['Admins cannot block an owner.', 'Owner tidak bisa diblokir admin.'],
    ['Owner accounts cannot be deleted.', 'Akun owner tidak bisa dihapus.'],
    ['You cannot block your own account.', 'Tidak bisa memblokir akun sendiri.'],
    ['You cannot delete your own account.', 'Tidak bisa menghapus akun sendiri.'],
    ['Approving', 'Menyetujui'],
    ['Rejecting', 'Menolak'],
    ['Blocking', 'Memblokir'],
    ['Unblocking', 'Membuka blokir'],
    ['Blocked', 'Diblokir'],
    ['Administrator', 'Administrator'],
    ['Minimum', 'Minimal'],
    ['Opened the admin panel', 'Membuka panel admin'],
    ['Cleared the activity log', 'Menghapus log aktivitas'],
    ['Signed in', 'Berhasil masuk'],
    ['Wrong password', 'Password salah'],
    ['New account created', 'Akun baru dibuat'],
    ['Blocked account attempted sign-in', 'Akun diblokir mencoba masuk'],
    ['Only admins may sign in', 'Hanya admin yang boleh masuk'],
    ['Password changed by the user', 'Password diubah sendiri'],
    ['Password recovered with a code', 'Password dipulihkan via kode'],
    ['Default admin account removed (default credentials)', 'Akun admin bawaan dihapus (kredensial default)'],
    ['Row', 'Baris'],
    ['Open', 'Buka'],

    /* ── Pro / kuota ─────────────────────────────────────────────── */
    ['ToolBoost Pro', 'ToolBoost Pro'],
    ['unlimited daily AI', 'AI tanpa batas harian'],
    ['unlimited files', 'File tanpa batas'],
    ['+ cloud sync', '+ sinkron cloud'],
    ['tables', 'tabel'],
    ['rows', 'baris'],
    ['entries', 'entri'],
    ['accounts', 'akun'],
    ['AI requests', 'permintaan AI'],
    ['AI messages per day', 'pesan AI per hari'],
    ['free messages without an account.', 'pesan gratis tanpa akun.'],
    ['free messages left — sign up to continue.', 'pesan gratis — daftar untuk lanjut.'],
    ['top-ranked models', 'model peringkat teratas'],
    ['per day', 'per hari'],
    ['per workspace', 'per workspace'],
    ['per purchase', 'per pembelian'],
    ['Max', 'Maks'],
    ['files', 'file'],
    ['Mid- and lower-ranked models', 'Model peringkat menengah ke bawah'],
    ['Run code & save locally', 'Jalankan kode & simpan lokal'],
    ['Full Deep Think & Write Mode', 'Deep Think & Write Mode penuh'],
    ['unlocked', 'terbuka'],
    ['Priority support', 'Prioritas dukungan'],
    ['Pro active', 'Pro aktif'],
    ['Active', 'Aktif'],
    ['Tap the button below — the admin WhatsApp chat opens with a ready-to-send message.',
     'Klik tombol di bawah — WhatsApp admin terbuka dengan pesan siap kirim.'],
    ['Complete the payment in that chat.', 'Selesaikan pembayaran lewat chat itu.'],
    ['The admin approves, and your account becomes Pro right away.',
     'Admin menyetujui, akunmu langsung jadi Pro.'],
    ['Your request is under review.', 'Permintaanmu sedang ditinjau.'],
    ['Message the admin on WhatsApp if you have not heard back.', 'Chat admin di WhatsApp kalau belum ada kabar.'],
    ['The admin WhatsApp number is not set yet.', 'Nomor WhatsApp admin belum diatur.'],
    ['The admin WhatsApp number is not set. Contact the admin another way.',
     'Nomor WhatsApp admin belum diatur. Hubungi admin lewat cara lain.'],
    ['Request recorded. Continue in the admin WhatsApp chat.', 'Permintaan dicatat. Lanjutkan di WhatsApp admin.'],
    ['Admins & owners get Pro access automatically.', 'Admin & owner otomatis punya akses Pro.'],
    ['AI usage today:', 'Pemakaian AI hari ini:'],

    /* ── Sinkron cloud ───────────────────────────────────────────── */
    ['Accounts & data shared across every device', 'Akun & data dibagi ke semua perangkat'],
    ['Push changes & pull data every 25 seconds', 'Kirim perubahan & tarik data tiap 25 detik'],
    ['Supabase (REST) or your own JSON endpoint', 'Supabase (REST) atau endpoint JSON sendiri'],
    ['Endpoint URL that accepts GET & PUT JSON', 'URL endpoint yang menerima GET & PUT JSON'],
    ['Public key from Settings → API', 'Kunci publik dari Settings → API'],
    ['Security note: the policy above is open so setup is quick. Passwords are still stored hashed, but anyone with the anon key can read this table. For a public site, replace it with stricter RLS or an Edge Function.',
     'Catatan keamanan: policy di atas terbuka agar setup cepat. Password tetap disimpan dalam bentuk hash, tapi siapa pun yang punya anon key bisa membaca tabel ini. Untuk situs publik, ganti dengan RLS yang lebih ketat atau Edge Function.'],
    ['Passwords are still stored hashed, but anyone with the anon key can read this table.',
     'Password tetap disimpan dalam bentuk hash, tapi siapa pun yang punya anon key bisa membaca tabel ini.'],
    ['Open this link on another device — the cloud settings install themselves',
     'Buka link ini di perangkat lain — pengaturan cloud terpasang otomatis'],
    ['One time only: create the table in Supabase', 'Sekali saja: buat tabelnya di Supabase'],
    ['Open Supabase → SQL Editor → paste this → Run.', 'Buka Supabase → SQL Editor → tempel ini → Run.'],
    ['Sync is not configured yet. Open Admin → Sync.', 'Sinkron belum diatur. Buka Admin → Sinkron.'],
    ['Ready — not synced yet', 'Siap — belum sinkron'],

    /* ── Daftar model ────────────────────────────────────────────── */
    ['random free model', 'acak dari model gratis'],
    ['fast responses', 'respons cepat'],
    ['deep reasoning', 'penalaran mendalam'],
    ['long context', 'konteks panjang'],
    ['coding agent', 'coding agent'],
    ['automatic router', 'router otomatis'],
    ['structured output', 'output terstruktur'],
    ['large context', 'context besar'],
    ['Top models · Pro', 'Model terbaik · Pro'],
    ['Top models · Pro required', 'Model terbaik · butuh Pro'],
    ['Available to everyone', 'Tersedia untuk semua'],
    ['All models', 'Semua model'],

    ['The last tab cannot be closed', 'Tab terakhir tidak bisa ditutup'],
    ['Local Terminal enabled. Start the companion app, then enter the token.',
     'Local Terminal diaktifkan. Jalankan companion app lalu masukkan token.'],
    ['Local Terminal disconnected', 'Local Terminal diputuskan'],
    ['✅ Local Terminal connected', '✅ Local Terminal terhubung'],
    ['Failed to load the code editor (Monaco)', 'Gagal memuat editor kode (Monaco)'],
    ['AI code applied!', 'Kode AI berhasil di-apply!'],
    ['Could not connect: the companion app is not running, the port is wrong, or your browser is blocking local-network access (see the note below).',
     'Gagal terhubung: companion app belum jalan, port salah, atau browser Anda memblokir akses local network (lihat catatan di bawah).'],
    ['AI chat is only for users with an account.', 'Chat AI hanya untuk pengguna yang sudah punya akun.'],
    ['This data comes from this device only', 'Data ini hanya dari perangkat ini'],
    ['Cloud sync is not configured, so sign-ups and sign-ins', 'Sinkron cloud belum diatur, jadi pendaftaran dan login'],
    ['from another browser or device', 'dari browser atau perangkat lain'],
    ['are not recorded here', 'tidak tercatat di sini'],
    ['. Enable sync so every', '. Aktifkan sinkron agar semua'],
    ['device shares one database.', 'perangkat memakai satu database yang sama.'],
    ['Set up sync', 'Atur sinkron'],
    ['🤖 Agent: auto-run only supports JavaScript files', '🤖 Agent: hanya mendukung auto-run untuk file JavaScript'],
    ['File code copied', 'Kode file disalin'],
    ['blocked', 'diblokir'],
    ['active again', 'aktif kembali'],
    ['This feature connects ToolBoost to a small program (a "companion app") that runs',
     'Fitur ini menghubungkan ToolBoost ke sebuah program kecil ("companion app") yang berjalan'],
    ['on your own computer', 'di komputer Anda sendiri'],
    ['. Once connected, ToolBoost can', '. Setelah terhubung, ToolBoost bisa'],
    ['on your computer — exactly as if you typed it into a terminal/command prompt yourself.',
     'di komputer Anda — sama seperti Anda mengetiknya langsung di terminal/command prompt.'],
    ['• Commands you or the AI run through this Terminal have', '• Perintah yang dijalankan AI/Anda lewat Terminal ini punya'],
    ['access to the files & system on your computer — nothing is sandboxed.',
     'akses ke file & sistem di komputer Anda — tidak dibatasi/dikurung (sandbox).'],
    ['• Only enable this if you trust the ToolBoost page you currently have open.',
     '• Hanya aktifkan kalau Anda mempercayai halaman ToolBoost yang sedang Anda buka saat ini.'],
    ['• The connection token is secret — never paste or share it anywhere else.',
     '• Token koneksi bersifat rahasia — jangan tempel/bagikan ke tempat lain.'],
    ['• You can disconnect at any time, and the companion app only runs while you keep it running.',
     '• Anda bisa memutus koneksi kapan saja, dan companion app hanya aktif selama programnya Anda jalankan.'],
    ['I understand the risk and', 'Saya mengerti risikonya dan'],
    ['this page to run commands on my computer.', 'halaman ini untuk menjalankan perintah di komputer saya.'],
    ['Skip Permission: the AI writes EVERY code change straight into the editor without you clicking Apply. Use with care.',
     'Skip Permission: AI langsung menerapkan SEMUA perubahan kode ke editor tanpa perlu klik Apply manual. Gunakan dengan hati-hati.'],
    ['Agent Mode: the AI applies code, runs it, then fixes itself on errors (max 4 attempts). JavaScript files only.',
     'Agent Mode: AI otomatis menerapkan kode, menjalankannya, lalu memperbaiki sendiri jika error (maks 4x percobaan). Hanya untuk file JavaScript.'],
    ['This link wants to connect ToolBoost to a data server:', 'Tautan ini ingin menyambungkan ToolBoost ke server data:'],
    ['Every account on this device will be sent there, and data from there will come into this device.',
     'Semua akun di perangkat ini akan dikirim ke sana, dan data dari sana akan masuk ke perangkat ini.'],
    ['Continue ONLY if you created this link yourself.', 'Lanjutkan HANYA jika Anda sendiri yang membuat tautan ini.'],
  ];

  /* Awalan untuk teks yang digabung dengan nilai variabel — [EN, ID] */
  var PREFIX_PAIRS = [
    ['Account created. Hello, ', 'Akun dibuat. Halo, '],
    ['Welcome back, ', 'Selamat datang kembali, '],
    ['Password changed. Welcome back, ', 'Password diganti. Halo lagi, '],
    ['Created account @', 'Membuat akun @'],
    ['Deleted account @', 'Menghapus akun @'],
    ['Added a row in ', 'Menambah baris di '],
    ['Deleted a row in ', 'Menghapus baris di '],
    ['Cleared table ', 'Mengosongkan tabel '],
    ['Saved raw JSON for table ', 'Menyimpan raw JSON tabel '],
    ['Overwrote table ', 'Menimpa seluruh tabel '],
    ['Reset password for @', 'Reset password @'],
    ['Setting ', 'Setting '],
    ['Plan @', 'Paket @'],
    ['Role @', 'Peran @'],
    ['Password @', 'Password @'],
    ['Approved Pro request @', 'Menyetujui permintaan Pro @'],
    ['Rejected Pro request @', 'Menolak permintaan Pro @'],
    ['Account @', 'Akun @'],
    ['Password must be at least ', 'Password minimal '],
    ['New password must be at least ', 'Password baru minimal '],
    ['Username not found: ', 'Username tidak ditemukan: '],
    ['Sync failed: ', 'Sinkron gagal: '],
    ['Import failed: ', 'Gagal import: '],
    ['Invalid JSON: ', 'JSON tidak valid: '],
    ['AI usage today: ', 'Pemakaian AI hari ini: '],
    ['You have used ', 'Kamu sudah memakai '],
    ['Remaining ', 'Sisa '],
    ['Pro · ', 'Pro · sisa '],
    ['Pro · forever', 'Pro · selamanya'],
    ['Pro · via role ', 'Pro · lewat peran '],
    ['Free · Pro ended ', 'Free · Pro berakhir '],
    ['Sent by a guest — replies appear on the device that sent the report.', 'Dikirim tamu — balasan muncul di perangkat yang mengirim laporan.'],
    ['pending', 'belum ditangani'],
    ['Sent ', 'Dikirim '],
    ['Last ', 'Terakhir '],
    ['Failed: ', 'Gagal: '],
    ['Model: ', 'Model: '],
    ['Fallback: ', 'Fallback: '],
    ['Auto picked ', 'Auto memilih ']
  ];

  /* Kata penghubung yang muncul di tengah teks bernomor */
  var JOINERS = [['of', 'dari'], ['until', 's/d'], ['signed out', 'keluar'], ['latest:', 'terbaru:']];

  /* ═══ Bangun kamus dua arah dari satu tabel ═══ */
  function buildDict(pairs, toEnglish) {
    var d = {};
    pairs.forEach(function (p) {
      var from = toEnglish ? p[1] : p[0];
      var to = toEnglish ? p[0] : p[1];
      if (!from || from === to) return;
      if (!(from in d)) d[from] = to;
      var n = from.replace(/\s+/g, ' ').trim();
      if (n !== from && !(n in d)) d[n] = to;
    });
    return d;
  }

  var DICT = { en: buildDict(PAIRS, true), id: buildDict(PAIRS, false) };
  var PREFIX = { en: PREFIX_PAIRS.map(function (p) { return [p[1], p[0]]; }), id: PREFIX_PAIRS.slice() };

  function joiner(word) {
    for (var i = 0; i < JOINERS.length; i++) {
      if (JOINERS[i][0] === word || JOINERS[i][1] === word) return lang === 'en' ? JOINERS[i][0] : JOINERS[i][1];
    }
    return word;
  }

  /* ═══ Deteksi bahasa ═══ */
  function browserLang() {
    var list = (navigator.languages && navigator.languages.length)
      ? navigator.languages : [navigator.language || 'en'];
    for (var i = 0; i < list.length; i++) {
      var t = String(list[i] || '').toLowerCase();
      if (t.indexOf('id') === 0 || t.indexOf('in') === 0) return 'id';
      if (t.indexOf('ms') === 0) return 'id';   // Melayu paling dekat ke Indonesia
    }
    return 'en';
  }
  function savedLang() {
    try { var v = localStorage.getItem(LANG_KEY); return (v === 'id' || v === 'en') ? v : null; } catch (e) { return null; }
  }

  var explicit = savedLang();            // pilihan user; null = ikut browser
  var lang = explicit || browserLang();
  var dict = DICT[lang];
  var prefixes = PREFIX[lang];

  /* ═══ Pencocokan ═══ */
  function norm(t) { return String(t).replace(/\s+/g, ' ').trim(); }

  // Banyak teks dibangun dari potongan ("key — frasa", "frasa (3)", "4 tabel",
  // "s/d 07 Okt"), jadi kunci diurai ke bagiannya, tiap bagian dicari sendiri,
  // lalu dirangkai kembali.
  var SEGMENTS = [
    [/^(.+?)(\s+·\s+)(.+)$/, function (m, tr) { return tr(m[1]) + m[2] + tr(m[3]); }],
    [/^([—–]\s*)(\S.*)$/, function (m, tr) { return m[1] + tr(m[2]); }],
    [/^(.+?)(\s+[—–]\s+)(.+)$/, function (m, tr) { return tr(m[1]) + m[2] + tr(m[3]); }],
    [/^(.+?)(\s*\(\d+\))$/, function (m, tr) { return tr(m[1]) + m[2]; }],
    [/^([\d.,]+)\s+(?:dari|of)\s+([\d.,]+)\s+(\S.*)$/, function (m, tr) {
      return m[1] + ' ' + joiner('of') + ' ' + m[2] + ' ' + tr(m[3]);
    }],
    [/^([\d.,]+\s+)(\S.*)$/, function (m, tr) { return m[1] + tr(m[2]); }],
    [/^(\+\s*)(\S.*)$/, function (m, tr) { return m[1] + tr(m[2]); }],
    [/^(@\S+\s+)(\S.*)$/, function (m, tr) { return m[1] + tr(m[2]); }],
    [/^(?:s\/d|until)(\s+.+)$/, function (m) { return joiner('until') + m[1]; }],
    [/^(.+?)\s+(?:keluar|signed out)$/, function (m, tr) { return tr(m[1]) + ' ' + joiner('signed out'); }],
    [/^(?:terbaru:|latest:)(\s+.+)$/, function (m) { return joiner('latest:') + m[1]; }]
  ];

  function lookup(key, depth) {
    depth = depth || 0;
    if (!key) return null;
    if (dict[key]) return dict[key];

    if (depth < 3) {
      var tr = function (part) {
        var got = lookup(part, depth + 1);
        return got === null ? part : got;
      };
      for (var s = 0; s < SEGMENTS.length; s++) {
        var m = key.match(SEGMENTS[s][0]);
        if (!m) continue;
        var out = SEGMENTS[s][1](m, tr);
        if (out !== key) return out;
      }
    }

    for (var i = 0; i < prefixes.length; i++) {
      var from = prefixes[i][0];
      if (from && key.indexOf(from) === 0 && key !== from) {
        var rest = key.slice(from.length);
        var inner = depth < 3 ? lookup(rest, depth + 1) : null;
        return prefixes[i][1] + (inner === null ? rest : inner);
      }
    }
    return null;
  }

  function translate(t) {
    var raw = String(t);
    var key = norm(raw);
    if (!key) return null;
    var out = lookup(key);
    if (out === null) return null;
    return raw.match(/^\s*/)[0] + out + raw.match(/\s*$/)[0];
  }

  /* ═══ Sweep DOM ═══ */
  // Jangan pernah sentuh kode user, keluaran program, balasan AI, atau
  // switcher bahasanya sendiri.
  var SKIP = ['SCRIPT', 'STYLE', 'TEXTAREA', 'CODE', 'PRE'];
  var SKIP_SEL = '#editor, .monaco-editor, .msg-body, #output-body, #terminal-log, .preview-frame, ' +
                 '#sandbox-frame, .tb-lang-switch, [data-no-i18n]';

  function sweep(root) {
    if (!root) return;
    if (root.nodeType === 1 && root.closest && root.closest(SKIP_SEL)) return;

    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) {
        if (!n.nodeValue || !/\S/.test(n.nodeValue)) return NodeFilter.FILTER_REJECT;
        var p = n.parentElement;
        if (!p || SKIP.indexOf(p.tagName) >= 0) return NodeFilter.FILTER_REJECT;
        if (p.closest && p.closest(SKIP_SEL)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    var nodes = [], n;
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach(function (node) {
      var out = translate(node.nodeValue);
      if (out !== null) node.nodeValue = out;
    });

    var ATTRS = ['placeholder', 'title', 'aria-label', 'alt'];
    var els = root.nodeType === 1 ? [root].concat([].slice.call(root.querySelectorAll('*'))) : [];
    els.forEach(function (el) {
      if (!el.getAttribute || (el.closest && el.closest(SKIP_SEL))) return;
      ATTRS.forEach(function (a) {
        var v = el.getAttribute(a);
        if (!v) return;
        var out = translate(v);
        if (out !== null) el.setAttribute(a, out);
      });
      if (el.tagName === 'OPTION' && el.textContent) {
        var o = translate(el.textContent);
        if (o !== null) el.textContent = o;
      }
    });
  }

  var pending = null;
  function sweepSoon(root) {
    clearTimeout(pending);
    pending = setTimeout(function () { sweep(root || document.body); }, 30);
  }

  /* ═══ Tombol ganti bahasa ═══ */
  var SWITCH_CSS =
    '.tb-lang-switch{display:inline-flex;align-items:center;gap:2px;padding:2px;border-radius:99px;' +
    'background:rgba(255,255,255,0.05);border:1px solid var(--border2,rgba(255,255,255,0.12));' +
    'font-family:var(--font-ui,system-ui),sans-serif;line-height:1;flex:none}' +
    '.tb-lang-switch button{appearance:none;border:none;background:transparent;cursor:pointer;' +
    'padding:5px 10px;border-radius:99px;font-size:11px;font-weight:700;letter-spacing:0.02em;' +
    'color:var(--text3,#8A8071);transition:background .15s,color .15s;font-family:inherit}' +
    '.tb-lang-switch button:hover{color:var(--text1,#F5EFE6);background:rgba(255,255,255,0.06)}' +
    '.tb-lang-switch button[aria-pressed="true"]{background:var(--accent,#C05A31);color:#fff}' +
    '.tb-lang-switch button:focus-visible{outline:2px solid var(--accent,#C05A31);outline-offset:1px}' +
    '@media(max-width:720px){.tb-lang-switch button{padding:5px 8px;font-size:10px}}';

  var LABELS = {
    auto: { en: 'Auto', id: 'Auto' },
    en: { en: 'EN', id: 'EN' },
    id: { en: 'ID', id: 'ID' }
  };
  var TITLES = {
    auto: { en: 'Follow browser language', id: 'Ikuti bahasa browser' },
    en: { en: 'Switch everything to English', id: 'Ganti semuanya ke bahasa Inggris' },
    id: { en: 'Switch everything to Indonesian', id: 'Ganti semuanya ke bahasa Indonesia' }
  };

  function injectCSS() {
    if (document.getElementById('tb-lang-css')) return;
    var st = document.createElement('style');
    st.id = 'tb-lang-css';
    st.textContent = SWITCH_CSS;
    (document.head || document.documentElement).appendChild(st);
  }

  function buildSwitch(host) {
    host.className = (host.className ? host.className + ' ' : '') + 'tb-lang-switch';
    host.setAttribute('role', 'group');
    host.setAttribute('aria-label', 'Language');
    host.innerHTML = '';
    ['auto', 'en', 'id'].forEach(function (v) {
      var b = document.createElement('button');
      b.type = 'button';
      b.dataset.tbLang = v;
      host.appendChild(b);
      b.addEventListener('click', function () { setLang(v === 'auto' ? null : v); });
    });
    paintSwitches();
  }

  function paintSwitches() {
    var active = explicit === null ? 'auto' : explicit;
    [].slice.call(document.querySelectorAll('.tb-lang-switch button[data-tb-lang]')).forEach(function (b) {
      var v = b.dataset.tbLang;
      b.textContent = LABELS[v][lang];
      b.title = TITLES[v][lang];
      b.setAttribute('aria-pressed', v === active ? 'true' : 'false');
      if (v === 'auto') b.textContent = LABELS.auto[lang] + (active === 'auto' ? ' · ' + lang.toUpperCase() : '');
    });
  }

  function mountSwitches() {
    injectCSS();
    [].slice.call(document.querySelectorAll('[data-tb-lang-switch]')).forEach(function (host) {
      if (host.dataset.tbLangMounted) return;
      host.dataset.tbLangMounted = '1';
      buildSwitch(host);
    });
  }

  /* Ganti bahasa tanpa reload: tabelnya simetris, jadi sweep ulang cukup. */
  function setLang(next) {
    if (next !== null && next !== 'en' && next !== 'id') return;
    explicit = next;
    try {
      if (next === null) localStorage.removeItem(LANG_KEY);
      else localStorage.setItem(LANG_KEY, next);
    } catch (e) {}
    var resolved = next || browserLang();
    lang = resolved;
    dict = DICT[lang];
    prefixes = PREFIX[lang];
    document.documentElement.lang = lang;
    sweep(document.body);
    paintSwitches();
    try {
      window.dispatchEvent(new CustomEvent('tb-lang-change', { detail: { lang: lang, explicit: explicit } }));
    } catch (e) {}
  }

  // confirm()/alert()/prompt() tidak pernah masuk DOM, jadi sweep tak bisa
  // menjangkaunya. Pesannya diterjemahkan baris demi baris di sini.
  function translateMessage(msg) {
    return String(msg).split('\n').map(function (line) {
      var out = translate(line);
      return out === null ? line : out;
    }).join('\n');
  }
  function patchDialogs() {
    ['alert', 'confirm', 'prompt'].forEach(function (fn) {
      var native = window[fn];
      if (typeof native !== 'function' || native.__tbPatched) return;
      var wrapped = function (msg) {
        var args = [].slice.call(arguments);
        if (typeof msg === 'string') args[0] = translateMessage(msg);
        return native.apply(window, args);
      };
      wrapped.__tbPatched = true;
      try { window[fn] = wrapped; } catch (e) {}
    });
  }

  function start() {
    document.documentElement.lang = lang;
    patchDialogs();
    mountSwitches();
    sweep(document.body);
    var mo = new MutationObserver(function (muts) {
      var needMount = false;
      muts.forEach(function (mu) {
        [].slice.call(mu.addedNodes).forEach(function (nd) {
          if (nd.nodeType === 1) {
            sweep(nd);
            if (nd.querySelector && (nd.matches('[data-tb-lang-switch]') || nd.querySelector('[data-tb-lang-switch]'))) needMount = true;
          } else if (nd.nodeType === 3) {
            var out = translate(nd.nodeValue || '');
            if (out !== null) nd.nodeValue = out;
          }
        });
      });
      if (needMount) mountSwitches();
    });
    mo.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();

  window.tbLang = {
    current: function () { return lang; },
    explicit: function () { return explicit; },
    t: function (s) { var o = translate(String(s)); return o === null ? s : o; },
    set: setLang,
    toEnglish: function () { setLang('en'); },
    auto: function () { setLang(null); },
    sweep: sweepSoon,
    mount: mountSwitches
  };
})();
